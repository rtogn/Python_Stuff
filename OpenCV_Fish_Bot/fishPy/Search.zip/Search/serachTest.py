import numpy as np
import cv2

img = cv2.imread("10x4.png", 1)

#print(img[2])

for row in range(len(img)):
    print(f"row {row +1}:", end='')
    print(img[row][0])
